package junit.util;

/**
 * This class defines the current version of JUnit
 */
public class Version {
	private Version() {
		// don't instantiate
	}
	public static String id() {
		return "3.2";
	}
}
